package Modelo;

public class Teste {
    
    
    public static void main(String[] args) {
        Carro[] a = new Carro[10];
        Object[]b;
        b = a;
        b[0] = "aa";
        

    }

}
