package Metodos;

import Modelo.Fabricante;
import Modelo.Fornecedor;
import Modelo.Marca;
import java.util.ArrayList;

public class Teste {


    public static void main(String[] args) throws ClassNotFoundException {
        ArrayList<Object>lista = new ArrayList<>();
        Generico.carregaLista("fabricantes.txt", lista);
        ArrayList<String> temp = new ArrayList<>();
  
        
    }

}
