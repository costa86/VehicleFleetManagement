package Metodos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Generico {

    public static String regexLetra = "^[a-zA-Z][a-zA-ZçÇ\\s]+";
    public static String regexLetraNum = "^[a-zA-Z][a-zA-ZçÇ\\s\\d]+";
    public static String regexAlfaNum = "[a-zA-Z\\d]+";
    public static String regexPlaca = "^[a-zA-Z][a-zA-Z]+\\-{1}\\d+$";
    public static String regexEmail = "^[a-zA-Z\\d]+[a-zA-Z\\d.-_]+\\@{1}[a-zA-Z]+\\.{1}[a-zA-Z\\.]+[a-zA-Z]+$";

    
    public static void carregaLista(String ficheiro, ArrayList<Object> lista) throws ClassNotFoundException {
        try (ObjectInputStream os = new ObjectInputStream(new FileInputStream(ficheiro))) {
            ArrayList<Object> listaObjetos = (ArrayList<Object>) os.readObject();
            for (Object obj : listaObjetos) {
                lista.add(obj);
            }
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } catch (IOException ex1) {
            JOptionPane.showMessageDialog(null, ex1.getMessage());
        }
    }

    public static String numeroEntre(int inicio, int fim, String regex, String texto) {
        String num;
        do {
            num = JOptionPane.showInputDialog(null, texto);
        } while (num == null || !num.matches(regex) || Integer.parseInt(num) > fim || Integer.parseInt(num) < inicio);
        return num;
    }

    public static String numero(String regex, String texto) {
        String num;
        do {
            num = JOptionPane.showInputDialog(null, texto);
        } while (num == null || !num.matches(regex));
        return num;
    }

    public static String campoValidado(String regex, String texto) {
        String num;
        do {
            num = JOptionPane.showInputDialog(null, texto);
        } while (num == null || !num.matches(regex));
        return num;
    }

    public static Double moeda(String texto) {
        String num;
        do {
            num = JOptionPane.showInputDialog(null, texto);
        } while (num == null || !num.matches("^\\d\\d{0,}\\,{0,1}\\d+$"));
        return Double.parseDouble(num.replace(",", "."));
    }

    public static String diaMesAno(String texto) {
        String dia = numeroEntre(1, 31, "\\d{2}", "Dia (2 dígitos)");
        String mes = numeroEntre(1, 12, "\\d{2}", "Mês (2 dígitos)");
        String ano = numeroEntre(1000, 3000, "\\d{4}", "Ano (4 dígitos)");
        return dia + "/" + mes + "/" + ano;
    }

    public static String horaMinuto(String texto) {
        String hora = numeroEntre(00, 23, "\\d{2}", "Hora (2 dígitos)");
        String minuto = numeroEntre(00, 59, "\\d{2}", "Minutos (2 dígitos)");
        return hora + ":" + minuto;
    }

    public static String TelefoneDDD(String texto) {
        String ddd = numero("\\d{2}", "DDD (2 dígitos)");
        String numero = numero("\\d{8,9}", "Número telefone (8 ou 9 dígitos)");
        return "(" + ddd + ") " + numero;
    }

    /**
     * Elimina espaços duplos, apara (trim) e converte para Upper
     *
     * @param campo
     * @return
     */
    public static String campoFormatado(JTextField campo) {
        return campo.getText().replaceAll("\\s+", " ").trim().toUpperCase();
    }

    public static void salvaFicheiro(String ficheiro, ArrayList<Object> lista) throws FileNotFoundException, IOException {
        try (ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream(ficheiro))) {
            os.writeObject(lista);
        }
    }

}
